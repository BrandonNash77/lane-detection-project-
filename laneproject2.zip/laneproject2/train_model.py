import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
import cv2
import os

# 1. Simple U-Net style model
def get_model():
    inputs = tf.keras.Input((256, 256, 3))
    # Downscale
    x = layers.Conv2D(32, 3, activation='relu', padding='same')(inputs)
    p = layers.MaxPooling2D()(x)
    # Bottleneck
    b = layers.Conv2D(64, 3, activation='relu', padding='same')(p)
    # Upscale
    u = layers.UpSampling2D()(b)
    x2 = layers.Conv2D(32, 3, activation='relu', padding='same')(u)
    # Output (1 channel for the lane mask)
    outputs = layers.Conv2D(1, 1, activation='sigmoid')(x2)
    return tf.keras.Model(inputs, outputs)

print("Loading dataset...")
images = []
masks = []

for i in range(500):
    img = cv2.imread(f'dataset/images/{i}.jpg')
    msk = cv2.imread(f'dataset/masks/{i}.png', 0)
    if img is not None and msk is not None:
        images.append(img / 255.0)
        masks.append(msk / 255.0)

X = np.array(images)
y = np.array(masks).reshape(-1, 256, 256, 1)

print(f"Data loaded: {X.shape[0]} images found.")

model = get_model()
model.compile(optimizer='adam', loss='binary_crossentropy')

print("Starting training (5 epochs)...")
model.fit(X, y, epochs=5, batch_size=16)

# Ensure models directory exists
if not os.path.exists('models'):
    os.makedirs('models')

model.save('models/best_model.h5')
print("\n✓ Success! Model saved to models/best_model.h5")