import cv2
import numpy as np
import os

os.makedirs('dataset/images', exist_ok=True)
os.makedirs('dataset/masks', exist_ok=True)

def generate_synthetic_lane(index):
    # Create empty black image
    img = np.zeros((256, 256, 3), dtype=np.uint8)
    mask = np.zeros((256, 256), dtype=np.uint8)
    
    # Draw a "road" (gray triangle)
    pts = np.array([[0, 256], [256, 256], [128, 100]], np.int32)
    cv2.fillPoly(img, [pts], (50, 50, 50))
    
    # Draw random lane lines (the "AI" needs to find these)
    left_x = np.random.randint(40, 80)
    right_x = np.random.randint(180, 220)
    
    cv2.line(img, (left_x, 256), (128, 100), (255, 255, 255), 3)
    cv2.line(img, (right_x, 256), (128, 100), (255, 255, 255), 3)
    
    # The mask is JUST the lines
    cv2.line(mask, (left_x, 256), (128, 100), 255, 3)
    cv2.line(mask, (right_x, 256), (128, 100), 255, 3)

    cv2.imwrite(f'dataset/images/{index}.jpg', img)
    cv2.imwrite(f'dataset/masks/{index}.png', mask)

print("Generating 500 images...")
for i in range(500): generate_synthetic_lane(i)
print("Done!")
