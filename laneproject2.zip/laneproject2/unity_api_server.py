from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import cv2
import base64
import tensorflow as tf

app = Flask(__name__)
CORS(app)

print("Loading model from models/best_model.h5...")
model = tf.keras.models.load_model('models/best_model.h5')
print("✓ Model loaded! Server ready.")

@app.route('/detect_lanes', methods=['POST'])
def detect_lanes():
    try:
        data = request.json
        image_data = base64.b64decode(data['image'])
        nparr = np.frombuffer(image_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # 1. AI Prediction
        img_resized = cv2.resize(img, (256, 256))
        img_normalized = img_resized.astype(np.float32) / 255.0
        img_batch = np.expand_dims(img_normalized, axis=0)
        prediction = model.predict(img_batch, verbose=0)[0]
        
        # 2. Create the Green Overlay (Settings)
        mask = (prediction > 0.5).astype(np.uint8) * 255
        mask_resized = cv2.resize(mask, (img.shape[1], img.shape[0]))
        
        # Create a green image same size as original
        green_overlay = np.zeros_like(img)
        green_overlay[mask_resized > 0] = [0, 255, 0] # BGR format: Green
        
        # 3. Blend original + green lines (Settings)
        # 0.6 is the road brightness, 0.4 is the green line brightness
        final_view = cv2.addWeighted(img, 0.6, green_overlay, 0.4, 0)
        
        # 4. Send back to Unity
        _, buffer = cv2.imencode('.jpg', final_view)
        mask_base64 = base64.b64encode(buffer).decode('utf-8')
        
        return jsonify({'success': True, 'mask': mask_base64})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500