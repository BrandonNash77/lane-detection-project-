using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System;

// 1. Ensure this name matches the filename LaneDetector.cs exactly!
public class LaneDetector : MonoBehaviour 
{
    [Header("Settings")]
    public string serverUrl = "http://localhost:5000/detect_lanes";
    public Camera vehicleCamera; // THIS IS THE SLOT YOU ARE LOOKING FOR
    
    private Texture2D laneMaskTexture;

    // 2. This helper class MUST be inside the LaneDetector class or marked Serializable
    [Serializable]
    public class DataResponse { public bool success; public string mask; }

    void Start() 
    { 
        if (vehicleCamera == null) vehicleCamera = GetComponent<Camera>();
        StartCoroutine(DetectionRoutine()); 
    }

    void OnGUI()
    {
        if (laneMaskTexture != null)
        {
            GUI.Label(new Rect(10, 10, 200, 20), "AI View (Lane Mask):");
            GUI.DrawTexture(new Rect(10, 30, 256, 256), laneMaskTexture);
        }
    }

    IEnumerator DetectionRoutine()
    {
        while (true)
        {
            yield return StartCoroutine(CaptureAndSend());
            yield return new WaitForSeconds(0.1f);
        }
    }

    IEnumerator CaptureAndSend()
    {
        // 3. Simple capture logic
        RenderTexture rt = new RenderTexture(256, 256, 24);
        vehicleCamera.targetTexture = rt;
        Texture2D screenShot = new Texture2D(256, 256, TextureFormat.RGB24, false);
        vehicleCamera.Render();
        RenderTexture.active = rt;
        screenShot.ReadPixels(new Rect(0, 0, 256, 256), 0, 0);
        vehicleCamera.targetTexture = null;
        RenderTexture.active = null;
        Destroy(rt);

        byte[] bytes = screenShot.EncodeToJPG();
        string base64Image = Convert.ToBase64String(bytes);
        string jsonData = "{\"image\":\"" + base64Image + "\"}";

        using (UnityWebRequest request = new UnityWebRequest(serverUrl, "POST"))
        {
            byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(jsonData);
            request.uploadHandler = new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                DataResponse response = JsonUtility.FromJson<DataResponse>(request.downloadHandler.text);
                byte[] maskBytes = Convert.FromBase64String(response.mask);
                if (laneMaskTexture == null) laneMaskTexture = new Texture2D(2, 2);
                laneMaskTexture.LoadImage(maskBytes);
            }
        }
    }
}